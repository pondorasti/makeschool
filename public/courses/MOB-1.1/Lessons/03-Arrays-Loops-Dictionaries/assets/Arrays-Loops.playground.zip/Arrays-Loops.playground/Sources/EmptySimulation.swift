import Foundation

open class EmptySimulation: Simulation {
    
}
