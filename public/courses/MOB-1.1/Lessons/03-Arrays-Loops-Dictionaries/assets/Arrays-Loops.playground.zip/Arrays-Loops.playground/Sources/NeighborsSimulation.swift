//
//  NeighborsSimulation.swift
//  Make-School-Arrays
//
//  Created by Yujin Ariza on 3/7/16.
//  Copyright © 2016 Make School. All rights reserved.
//

import Foundation

open class NeighborsSimulation: Simulation {
    open func countNeighbors(grid: [[Character?]], column x: Int, row y: Int) -> Int {
        return 0
    }
}
