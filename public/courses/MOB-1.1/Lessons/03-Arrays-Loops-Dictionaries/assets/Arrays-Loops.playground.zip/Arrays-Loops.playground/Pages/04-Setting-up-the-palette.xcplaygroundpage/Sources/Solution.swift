import Foundation

public func solutionArray() -> [Character?] {
    return ["🐱", "🐱", "🐱", "🐱", "🐱", nil, nil, nil]
}