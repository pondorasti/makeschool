import UIKit

/*:
 ### Example: closure with statements
 */

var brunch : () -> () = {
    print("Coffee and bagels")
}


/*:
 Everything inside the braces {} is the closure. And it is assigned to a variable (could be to a constant too). This is possible because closures are first-class.
 
Note: First-class just means that there are no restrictions in the object's use. It can be created, stored, passed, assigned, return as value. You can treat it as you would any other value or object

Q1: What is the type of the closure?
 
We can add it in the decaration.
 
Todo: Rewrite with type declaration & call
 */
brunch()
/*:
 ### Example: closure with parameters
 */

let brunchOption:(String) -> () = { option in
    print(option)
}

/*:
 
 Q2: What is the type of the closure?
 
 We can use the value passed inside the statements of the closure by placing a parameter name followed by the in keyword.
 
 The in keyword separates the parameter name with the body of the closure.
 When calling the closure, since it accepts a String, we pass the string in that moment.
 
 Make a call to it.
 */
brunchOption("Dim sum")


/*:
 ### Example: closure that returns a value
 */

let brunchOptionLocation:(String) -> (String) = { option in
    let greeting = option + " @ Castro St."
    return greeting
}


/*:
 Q3: What is the meaning of (String) -> (String)?
 
 Q4: How are we using option?
 
 Q5: How do we return and show the output?
 */
var medi = brunchOptionLocation("Brownies")
print(medi)

/*:
 ### Example: passing a closure as a function parameter
 */

func getBrunch(optionClosure:()->()) {
    print("Going for brunch.")
    optionClosure()
}

getBrunch(optionClosure: {
    print("Anything edible")
})

/*:
 Q6: What is the output?
 
 Q7: Why is the closure statement is not executed?
 */
