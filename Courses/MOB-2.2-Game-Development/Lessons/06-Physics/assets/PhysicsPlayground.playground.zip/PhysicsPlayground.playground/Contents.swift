 import SpriteKit
 import PlaygroundSupport

 //Setting the scene
 let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 480,height: 320))
 let scene = SKScene(size: CGSize(width: 480, height: 320))
 sceneView.showsFPS = true
 sceneView.showsPhysics = true
 scene.physicsWorld.gravity = .zero
 scene.physicsBody = SKPhysicsBody(edgeLoopFrom: scene.frame)
 sceneView.presentScene(scene)
 PlaygroundPage.current.needsIndefiniteExecution = true
 PlaygroundPage.current.liveView = sceneView

 //Creating the first sprite
 let square = SKSpriteNode(color: UIColor.purple, size: CGSize(width: 30, height: 30))
 square.name = "shape"
 square.position = CGPoint(x: scene.size.width * 0.25,
                           y: scene.size.height * 0.50)
 scene.addChild(square)
 
 //Physics body settings of the sprite
 square.physicsBody = SKPhysicsBody(circleOfRadius: square.size.width/2)
 //square.physicsBody?.isDynamic =

 
 //Creating tiny nodes all over
 func spawnSand() {
    let sand = SKSpriteNode(color: UIColor.red, size: CGSize(width: 5, height: 5))
    sand.position = CGPoint(x: random(min: 0.0, max: scene.size.width), y: scene.size.height - sand.size.height)
    sand.physicsBody = SKPhysicsBody(circleOfRadius:0.1)
    sand.name = "sand"
    //sand.physicsBody!.restitution =
    //sand.physicsBody!.density =
    scene.addChild(sand)

 }
 
 //Applying an impulse
 func shake() {
    scene.enumerateChildNodes(withName: "sand") { node, _ in
        node.physicsBody!.applyImpulse(
            CGVector(dx: 0, dy: random(min: 20, max: 40))
        )
    }
    scene.enumerateChildNodes(withName: "shape") { node, _ in node.physicsBody!.applyImpulse(
        CGVector(dx: random(min:20, max:60),
                 dy: random(min:20, max:60))
        ) }
    delay(seconds: 3, completion: shake)
 }
 
 delay(seconds: 2.0) {
    scene.physicsWorld.gravity = CGVector(dx: 0, dy: -9.8) //🌎
    scene.run(SKAction.repeat(SKAction.sequence([SKAction.run(spawnSand), SKAction.wait(forDuration: 0.1)]), count: 100))
    //delay(seconds: 12, completion: shake)
 }

 // Experimenting with other type of physics bodies
 let trianglePath = CGMutablePath()
 trianglePath.move(to: CGPoint(x: -square.size.width/2,
                               y: -square.size.height/2))
 trianglePath.addLine(to: CGPoint(x: square.size.width/2,
                                  y: -square.size.height/2))
 trianglePath.addLine(to: CGPoint(x: 0, y: square.size.height/2))
 trianglePath.addLine(to: CGPoint(x: -square.size.width/2,
                                  y: -square.size.height/2))
 //square.physicsBody = SKPhysicsBody(polygonFrom: trianglePath)
