
import UIKit

class Person {
    let name: String
    var apartment: Apartment?
    
    init(name: String) {
        self.name = name
    }
    
    deinit {
        print("De initialized Person")
    }
}

class Apartment {
    weak var person: Person?
    var unit: String
    
    init(unit: String) {
        self.unit = unit
    }
    
    deinit {
        print("De initialized Apartment")
    }
}

var person1: Person? = Person(name: "Jack")
var apt: Apartment? = Apartment(unit: "4A")

person1?.apartment = apt
apt?.person = person1

var person2: Person? = nil
person2 = person1


person1 = nil
person2 = nil
//apt = nil
//
//person1 = nil
//person2 = nil

