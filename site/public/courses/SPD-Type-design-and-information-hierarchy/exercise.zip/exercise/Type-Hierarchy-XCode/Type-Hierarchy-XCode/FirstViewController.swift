//
//  FirstViewController.swift
//  Type-Hierarchy-XCode
//
//  Created by Mitchell Hudson on 11/14/18.
//  Copyright © 2018 Mitchell Hudson. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

